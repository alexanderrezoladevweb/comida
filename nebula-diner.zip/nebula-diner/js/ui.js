/**
 * NEBULA DINER - Interfaz de usuario
 * Renderizado, paneles, notificaciones y feedback visual.
 */

const UI = {
  currentPanel: null,

  init() {
    // Navegación inferior
    document.querySelectorAll(".nav-btn").forEach(btn => {
      btn.addEventListener("click", () => {
        const panel = btn.dataset.panel;
        this.openPanel(panel);
        document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));
        btn.classList.add("active");
      });
    });

    document.getElementById("close-panel").addEventListener("click", () => this.closePanel());
    document.getElementById("panel-overlay").addEventListener("click", (e) => {
      if (e.target.id === "panel-overlay") this.closePanel();
    });

    document.getElementById("rating-ok").addEventListener("click", () => {
      document.getElementById("rating-modal").classList.add("hidden");
    });

    document.getElementById("unlock-ok").addEventListener("click", () => {
      document.getElementById("unlock-modal").classList.add("hidden");
    });
  },

  // ========== HUD ==========
  updateHUD() {
    document.getElementById("money-display").textContent = Math.floor(game.state.money).toLocaleString();
    document.getElementById("reputation-display").textContent = game.state.reputation;
    document.getElementById("day-display").textContent = `Día ${game.state.day}`;
    document.getElementById("location-display").textContent = game.getLocation().name;
  },

  // ========== MESAS / CLIENTES ==========
  renderTables() {
    const container = document.getElementById("tables-container");
    container.innerHTML = "";

    game.tables.forEach(table => {
      const card = document.createElement("div");
      card.className = `table-card ${table.status === "empty" ? "empty" : "occupied"}`;
      card.dataset.tableId = table.id;

      if (table.status === "empty") {
        card.innerHTML = `
          <div style="font-size:1.8rem;opacity:0.4;">🪑</div>
          <div class="alien-name" style="color:var(--text-muted)">Mesa libre</div>
        `;
      } else {
        const alien = table.customer;
        const dish = table.order;
        let statusText = "";
        let serveReady = false;

        if (table.status === "waiting") {
          statusText = `Espera: ${Math.ceil(table.patienceLeft)}s`;
        } else if (table.status === "cooking") {
          const pct = Math.min(100, (table.cookProgress / table.cookTimeNeeded) * 100);
          statusText = `Cocinando... ${Math.floor(pct)}%`;
        } else if (table.status === "ready") {
          statusText = "¡Listo para servir!";
          serveReady = true;
        }

        card.innerHTML = `
          <div class="alien-timer">${statusText}</div>
          <div class="alien-avatar" style="border-color:${alien.color}">${alien.emoji}</div>
          <div class="alien-name">${alien.name}</div>
          <div class="alien-order">${dish.emoji} ${dish.name}</div>
          <button class="serve-btn ${serveReady ? "ready" : ""}" data-action="serve">
            ${serveReady ? "Servir" : table.status === "waiting" ? "Cocinar" : "..."}
          </button>
        `;

        const btn = card.querySelector(".serve-btn");
        if (table.status === "waiting") {
          btn.classList.add("ready");
          btn.textContent = "Cocinar";
          btn.onclick = () => this.tryCook(table.id);
        } else if (table.status === "ready") {
          btn.onclick = () => this.tryServe(table.id);
        }
      }

      container.appendChild(card);
    });
  },

  renderCookingSlots() {
    const container = document.getElementById("cooking-slots");
    const loc = game.getLocation();
    container.innerHTML = "";

    for (let i = 0; i < loc.cookingSlots; i++) {
      const slot = document.createElement("div");
      slot.className = "cooking-slot";

      // Buscar si hay algo cocinándose
      const cookingTable = game.tables.find(t => t.status === "cooking");
      if (cookingTable && i === 0) {
        // Simplificado: mostramos el primero que esté cocinando
        const pct = Math.min(100, (cookingTable.cookProgress / cookingTable.cookTimeNeeded) * 100);
        slot.classList.add("active");
        slot.innerHTML = `
          <div style="font-size:1.2rem">${cookingTable.order.emoji}</div>
          <div class="progress" style="width:${pct}%"></div>
        `;
      } else {
        slot.textContent = "Libre";
      }
      container.appendChild(slot);
    }

    // Mostrar todos los que están cocinando
    const cookingOnes = game.tables.filter(t => t.status === "cooking");
    if (cookingOnes.length > 0) {
      container.innerHTML = "";
      cookingOnes.forEach(t => {
        const pct = Math.min(100, (t.cookProgress / t.cookTimeNeeded) * 100);
        const slot = document.createElement("div");
        slot.className = "cooking-slot active";
        slot.innerHTML = `
          <div style="font-size:1.1rem">${t.order.emoji}</div>
          <div style="font-size:0.65rem;margin-top:2px">${t.customer.name}</div>
          <div class="progress" style="width:${pct}%"></div>
        `;
        container.appendChild(slot);
      });
      // Rellenar slots vacíos
      for (let i = cookingOnes.length; i < loc.cookingSlots; i++) {
        const slot = document.createElement("div");
        slot.className = "cooking-slot";
        slot.textContent = "Libre";
        container.appendChild(slot);
      }
    }
  },

  tryCook(tableId) {
    const table = game.tables.find(t => t.id === tableId);
    if (!table) return;

    if (!game.canCook(table.order.id)) {
      this.notify("¡No tienes suficientes ingredientes!", "warning");
      this.openPanel("shop");
      return;
    }

    const ok = game.startCooking(tableId);
    if (ok) {
      this.notify(`Cocinando ${table.order.emoji} ${table.order.name}...`, "success");
      this.renderTables();
      this.renderCookingSlots();
      this.updateHUD();
    }
  },

  tryServe(tableId) {
    const result = game.serveCustomer(tableId);
    if (!result) return;

    this.showRating(result);
    this.renderTables();
    this.renderCookingSlots();
    this.updateHUD();

    // Comprobar desbloqueo de local
    const unlocked = game.checkLocationUnlock();
    if (unlocked) {
      setTimeout(() => this.showUnlock(unlocked), 800);
    }
  },

  showRating(result) {
    const modal = document.getElementById("rating-modal");
    document.getElementById("rating-alien").textContent = result.alien.emoji;
    const stars = "★".repeat(Math.floor(result.rating)) + (result.rating % 1 ? "½" : "") + "☆".repeat(5 - Math.ceil(result.rating));
    document.getElementById("rating-stars").textContent = stars;
    
    let text = "";
    if (result.rating >= 4.5) text = "¡Increíble! El cliente está eufórico.";
    else if (result.rating >= 3.5) text = "Muy bueno. Sonríe satisfecho.";
    else if (result.rating >= 2.5) text = "Aceptable. Podría estar mejor.";
    else text = "No le ha gustado mucho...";
    
    document.getElementById("rating-text").textContent = text;
    document.getElementById("rating-money").textContent = `+$${result.money} (propina $${result.tip})`;
    modal.classList.remove("hidden");
  },

  showUnlock(location) {
    document.getElementById("unlock-name").textContent = location.name;
    document.getElementById("unlock-desc").textContent = location.description;
    document.getElementById("unlock-modal").classList.remove("hidden");
    this.notify(`¡Nuevo local: ${location.name}!`, "success");
    this.renderTables();
    this.renderCookingSlots();
    this.updateHUD();
  },

  // ========== PANELES ==========
  openPanel(name) {
    this.currentPanel = name;
    const overlay = document.getElementById("panel-overlay");
    const title = document.getElementById("panel-title");
    const content = document.getElementById("panel-content");

    const titles = {
      customers: "Clientes & Estado",
      menu: "Menú del Local",
      kitchen: "Cocina & Slots",
      furniture: "Catálogo de Muebles",
      shop: "Mercado de Ingredientes",
      upgrade: "Mejoras Permanentes"
    };

    title.textContent = titles[name] || name;
    content.innerHTML = "";

    if (name === "customers") this.renderCustomersPanel(content);
    else if (name === "menu") this.renderMenuPanel(content);
    else if (name === "kitchen") this.renderKitchenPanel(content);
    else if (name === "furniture") this.renderFurniturePanel(content);
    else if (name === "shop") this.renderShopPanel(content);
    else if (name === "upgrade") this.renderUpgradePanel(content);

    overlay.classList.remove("hidden");
  },

  closePanel() {
    document.getElementById("panel-overlay").classList.add("hidden");
    this.currentPanel = null;
    document.querySelectorAll(".nav-btn").forEach(b => b.classList.remove("active"));
  },

  renderCustomersPanel(container) {
    const active = game.tables.filter(t => t.status !== "empty");
    container.innerHTML = `
      <div class="section-title">Estadísticas</div>
      <div class="item-card">
        <div class="item-info">
          <div class="item-name">Clientes atendidos</div>
          <div class="item-desc">${game.state.customersServed}</div>
        </div>
      </div>
      <div class="item-card">
        <div class="item-info">
          <div class="item-name">Valoración media</div>
          <div class="item-desc">${game.state.averageRating ? game.state.averageRating.toFixed(1) : "—"} ★</div>
        </div>
      </div>
      <div class="item-card">
        <div class="item-info">
          <div class="item-name">Dinero total ganado</div>
          <div class="item-desc">$${Math.floor(game.state.totalEarned).toLocaleString()}</div>
        </div>
      </div>
      <div class="section-title">Clientes actuales (${active.length})</div>
    `;

    if (active.length === 0) {
      container.innerHTML += `<div class="empty-state">Nadie en el local ahora mismo.<br>¡Espera un poco!</div>`;
      return;
    }

    active.forEach(t => {
      const div = document.createElement("div");
      div.className = "item-card";
      div.innerHTML = `
        <div class="item-icon">${t.customer.emoji}</div>
        <div class="item-info">
          <div class="item-name">${t.customer.name}</div>
          <div class="item-desc">${t.order.emoji} ${t.order.name} · ${t.status}</div>
        </div>
      `;
      container.appendChild(div);
    });
  },

  renderMenuPanel(container) {
    const categories = ["basico", "intermedio", "gourmet"];
    categories.forEach(cat => {
      const dishes = GAME_DATA.dishes.filter(d => d.category === cat);
      if (dishes.length === 0) return;

      const title = document.createElement("div");
      title.className = "section-title";
      title.textContent = cat === "basico" ? "Básicos" : cat === "intermedio" ? "Intermedios" : "Gourmet / Alienígenas";
      container.appendChild(title);

      dishes.forEach(d => {
        const unlocked = d.unlock <= game.state.locationId;
        const inMenu = game.state.menu.includes(d.id);
        const card = document.createElement("div");
        card.className = "item-card";
        card.style.opacity = unlocked ? 1 : 0.45;

        card.innerHTML = `
          <div class="item-icon">${d.emoji}</div>
          <div class="item-info">
            <div class="item-name">${d.name}</div>
            <div class="item-desc">$${d.price} · ${d.cookTime}s · ${d.tags.slice(0,3).join(", ")}</div>
            ${!unlocked ? `<div class="item-desc" style="color:var(--danger)">Se desbloquea en local nivel ${d.unlock + 1}</div>` : ""}
          </div>
          <div class="item-actions">
            ${unlocked ? `
              <button class="btn-small ${inMenu ? "toggle-on" : "toggle-off"}" data-dish="${d.id}">
                ${inMenu ? "En menú" : "Añadir"}
              </button>
            ` : ""}
          </div>
        `;

        if (unlocked) {
          card.querySelector("button").onclick = () => {
            game.toggleMenuDish(d.id);
            this.renderMenuPanel(container);
            this.notify(inMenu ? `Quitado del menú` : `Añadido al menú`, "success");
          };
        }
        container.appendChild(card);
      });
    });
  },

  renderKitchenPanel(container) {
    container.innerHTML = `
      <div class="section-title">Estado de la cocina</div>
      <div class="item-card">
        <div class="item-info">
          <div class="item-name">Slots de cocción</div>
          <div class="item-desc">${game.getLocation().cookingSlots} disponibles</div>
        </div>
      </div>
      <div class="section-title">Inventario actual</div>
    `;

    const inv = Object.entries(game.state.inventory).filter(([_, qty]) => qty > 0);
    if (inv.length === 0) {
      container.innerHTML += `<div class="empty-state">Inventario vacío. Ve al Mercado.</div>`;
      return;
    }

    inv.forEach(([id, qty]) => {
      const ing = game.getIngredient(id);
      if (!ing) return;
      const card = document.createElement("div");
      card.className = "item-card";
      card.innerHTML = `
        <div class="item-icon">${ing.emoji}</div>
        <div class="item-info">
          <div class="item-name">${ing.name}</div>
          <div class="item-desc">Cantidad: ${qty}</div>
        </div>
      `;
      container.appendChild(card);
    });
  },

  renderFurniturePanel(container) {
    const cats = ["mesa", "silla", "luz", "planta", "deco", "utilidad"];
    const catNames = { mesa: "Mesas", silla: "Sillas", luz: "Iluminación", planta: "Plantas", deco: "Decoración", utilidad: "Utilidad" };

    cats.forEach(cat => {
      const items = GAME_DATA.furniture.filter(f => f.category === cat);
      if (!items.length) return;

      const title = document.createElement("div");
      title.className = "section-title";
      title.textContent = catNames[cat];
      container.appendChild(title);

      items.forEach(f => {
        const owned = game.state.ownedFurniture.includes(f.id);
        const card = document.createElement("div");
        card.className = "item-card";
        card.innerHTML = `
          <div class="item-icon">${f.emoji}</div>
          <div class="item-info">
            <div class="item-name">${f.name}</div>
            <div class="item-desc">${f.desc}</div>
            ${Object.keys(f.bonus || {}).length ? `<div class="item-desc" style="color:var(--accent-glow)">Bono: ${JSON.stringify(f.bonus)}</div>` : ""}
          </div>
          <div class="item-actions">
            ${owned 
              ? `<span style="color:var(--success);font-weight:700;font-size:0.8rem">✓ Tuyo</span>`
              : `<button class="btn-small" data-id="${f.id}">$${f.price}</button>`
            }
          </div>
        `;

        if (!owned) {
          card.querySelector("button").onclick = () => {
            if (game.buyFurniture(f.id)) {
              this.notify(`¡Comprado ${f.name}!`, "money");
              this.renderFurniturePanel(container);
              this.updateHUD();
            } else {
              this.notify("No tienes suficiente dinero", "warning");
            }
          };
        }
        container.appendChild(card);
      });
    });
  },

  renderShopPanel(container) {
    container.innerHTML = `<div class="section-title">Comprar ingredientes (x5)</div>`;

    GAME_DATA.ingredients.forEach(ing => {
      const qty = game.state.inventory[ing.id] || 0;
      const card = document.createElement("div");
      card.className = "item-card";
      card.innerHTML = `
        <div class="item-icon">${ing.emoji}</div>
        <div class="item-info">
          <div class="item-name">${ing.name}</div>
          <div class="item-desc">Tienes: ${qty} · $${ing.price} c/u</div>
        </div>
        <div class="item-actions">
          <button class="btn-small" data-id="${ing.id}">$${ing.price * 5}</button>
        </div>
      `;
      card.querySelector("button").onclick = () => {
        if (game.buyIngredient(ing.id, 5)) {
          this.notify(`+5 ${ing.name}`, "money");
          this.renderShopPanel(container);
          this.updateHUD();
        } else {
          this.notify("Dinero insuficiente", "warning");
        }
      };
      container.appendChild(card);
    });
  },

  renderUpgradePanel(container) {
    container.innerHTML = `
      <div class="section-title">Progresión de locales</div>
    `;

    GAME_DATA.locations.forEach((loc, i) => {
      const current = i === game.state.locationId;
      const unlocked = i <= game.state.locationId;
      const card = document.createElement("div");
      card.className = "item-card";
      card.style.borderColor = current ? "var(--accent)" : "";
      card.innerHTML = `
        <div class="item-icon">${unlocked ? "🏠" : "🔒"}</div>
        <div class="item-info">
          <div class="item-name">${loc.name} ${current ? "(Actual)" : ""}</div>
          <div class="item-desc">${loc.description}</div>
          <div class="item-desc">Mesas: ${loc.maxTables} · Slots cocina: ${loc.cookingSlots}</div>
          ${!unlocked ? `<div class="item-desc" style="color:var(--reputation)">Requiere $${loc.unlockMoney.toLocaleString()} ganados</div>` : ""}
        </div>
      `;
      container.appendChild(card);
    });

    const title2 = document.createElement("div");
    title2.className = "section-title";
    title2.textContent = "Mejoras permanentes";
    container.appendChild(title2);

    GAME_DATA.upgrades.forEach(u => {
      const owned = game.state.purchasedUpgrades.includes(u.id);
      const canBuy = !u.requires || game.state.purchasedUpgrades.includes(u.requires);
      const card = document.createElement("div");
      card.className = "item-card";
      card.style.opacity = canBuy || owned ? 1 : 0.5;
      card.innerHTML = `
        <div class="item-icon">${u.emoji}</div>
        <div class="item-info">
          <div class="item-name">${u.name}</div>
          <div class="item-desc">${u.desc}</div>
        </div>
        <div class="item-actions">
          ${owned 
            ? `<span style="color:var(--success);font-weight:700">✓</span>`
            : canBuy 
              ? `<button class="btn-small" data-id="${u.id}">$${u.price}</button>`
              : `<span style="font-size:0.75rem;color:var(--text-muted)">Bloqueado</span>`
          }
        </div>
      `;
      if (!owned && canBuy) {
        card.querySelector("button").onclick = () => {
          if (game.buyUpgrade(u.id)) {
            this.notify(`¡Mejora comprada!`, "success");
            this.renderUpgradePanel(container);
            this.updateHUD();
          } else {
            this.notify("Dinero insuficiente", "warning");
          }
        };
      }
      container.appendChild(card);
    });
  },

  // ========== NOTIFICACIONES ==========
  notify(text, type = "success") {
    const container = document.getElementById("notifications");
    const el = document.createElement("div");
    el.className = `notification ${type}`;
    el.textContent = text;
    container.appendChild(el);
    setTimeout(() => el.remove(), 2600);
  },

  // ========== LOOP DE RENDER ==========
  startRenderLoop() {
    const loop = () => {
      if (game.isRunning) {
        this.updateHUD();
        this.renderTables();
        this.renderCookingSlots();
      }
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  }
};
