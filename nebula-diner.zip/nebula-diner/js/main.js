/**
 * NEBULA DINER - Punto de entrada
 */

document.addEventListener("DOMContentLoaded", () => {
  // Simular carga
  const fill = document.querySelector(".loader-fill");
  const text = document.querySelector(".loader-text");
  const messages = [
    "Calibrando gravedad de la cocina...",
    "Despertando a los Gloppix...",
    "Cargando recetas secretas...",
    "Alineando las estrellas del menú...",
    "¡Listo para abrir!"
  ];

  let progress = 0;
  let msgIndex = 0;

  const loadInterval = setInterval(() => {
    progress += 18 + Math.random() * 12;
    if (progress > 100) progress = 100;
    fill.style.width = progress + "%";

    if (progress > msgIndex * 22 && msgIndex < messages.length - 1) {
      msgIndex++;
      text.textContent = messages[msgIndex];
    }

    if (progress >= 100) {
      clearInterval(loadInterval);
      setTimeout(() => {
        document.getElementById("loading-screen").classList.add("hidden");
        document.getElementById("title-screen").classList.remove("hidden");

        // Mostrar botón continuar si hay save
        if (game.load()) {
          document.getElementById("btn-continue").classList.remove("hidden");
        }
      }, 400);
    }
  }, 180);

  // Botones de título
  document.getElementById("btn-new-game").addEventListener("click", () => {
    localStorage.removeItem("nebulaDinerSave");
    game.state = game.getDefaultState();
    startGame();
  });

  document.getElementById("btn-continue").addEventListener("click", () => {
    startGame();
  });

  function startGame() {
    document.getElementById("title-screen").classList.add("hidden");
    document.getElementById("game-ui").classList.remove("hidden");

    UI.init();
    game.start();
    UI.startRenderLoop();
    UI.updateHUD();
    UI.renderTables();
    UI.renderCookingSlots();

    UI.notify("¡Bienvenido a tu cafetería espacial!", "success");
  }
});
