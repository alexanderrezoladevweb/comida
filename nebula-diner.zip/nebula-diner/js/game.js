/**
 * NEBULA DINER - Lógica principal del juego
 * Sistema de estado, clientes, cocina, economía y progresión.
 */

class NebulaDiner {
  constructor() {
    this.state = this.getDefaultState();
    this.tables = [];
    this.cookingQueue = [];
    this.customers = [];
    this.tickInterval = null;
    this.spawnTimer = 0;
    this.dayTimer = 0;
    this.isRunning = false;
  }

  getDefaultState() {
    return {
      money: 80,
      reputation: 0,
      day: 1,
      locationId: 0,
      menu: ["cafe", "batido", "hamburguesa", "tostada", "sopa", "galletas"],
      inventory: {
        cafe: 15, fruta: 10, leche: 10, carne: 8, pan: 12, verdura: 10,
        energia: 6, caldo: 8, harina: 10, azucar: 10
      },
      ownedFurniture: ["mesa_basica", "silla_simple", "lampara_simple"],
      purchasedUpgrades: [],
      totalEarned: 80,
      customersServed: 0,
      averageRating: 0,
      ratingSum: 0,
      ratingCount: 0
    };
  }

  load() {
    try {
      const saved = localStorage.getItem("nebulaDinerSave");
      if (saved) {
        this.state = { ...this.getDefaultState(), ...JSON.parse(saved) };
        return true;
      }
    } catch (e) {}
    return false;
  }

  save() {
    try {
      localStorage.setItem("nebulaDinerSave", JSON.stringify(this.state));
    } catch (e) {}
  }

  getLocation() {
    return GAME_DATA.locations[this.state.locationId];
  }

  getAvailableDishes() {
    return GAME_DATA.dishes.filter(d => 
      d.unlock <= this.state.locationId && this.state.menu.includes(d.id)
    );
  }

  getDish(id) {
    return GAME_DATA.dishes.find(d => d.id === id);
  }

  getAlien(id) {
    return GAME_DATA.aliens.find(a => a.id === id);
  }

  getIngredient(id) {
    return GAME_DATA.ingredients.find(i => i.id === id);
  }

  // ========== ECONOMÍA ==========
  canAfford(price) {
    return this.state.money >= price;
  }

  spend(amount) {
    if (!this.canAfford(amount)) return false;
    this.state.money -= amount;
    this.save();
    return true;
  }

  earn(amount) {
    this.state.money += amount;
    this.state.totalEarned += amount;
    this.checkLocationUnlock();
    this.save();
  }

  addReputation(amount) {
    const bonus = this.state.purchasedUpgrades.includes("reputacion") ? 1.2 : 1;
    this.state.reputation += Math.round(amount * bonus);
    this.save();
  }

  // ========== PROGRESIÓN DE LOCALES ==========
  checkLocationUnlock() {
    const next = GAME_DATA.locations[this.state.locationId + 1];
    if (next && this.state.totalEarned >= next.unlockMoney) {
      this.state.locationId++;
      this.initTables();
      this.save();
      return next;
    }
    return null;
  }

  // ========== MESAS ==========
  initTables() {
    const loc = this.getLocation();
    this.tables = [];
    for (let i = 0; i < loc.maxTables; i++) {
      this.tables.push({
        id: i,
        customer: null,
        order: null,
        status: "empty", // empty | waiting | eating | done
        patienceLeft: 0,
        cookProgress: 0,
        cookTimeNeeded: 0,
        servedDish: null
      });
    }
  }

  // ========== CLIENTES ==========
  spawnCustomer() {
    const emptyTables = this.tables.filter(t => t.status === "empty");
    if (emptyTables.length === 0) return null;

    // Probabilidad influida por reputación
    const baseChance = 0.35 + Math.min(this.state.reputation / 500, 0.4);
    if (Math.random() > baseChance) return null;

    const table = emptyTables[Math.floor(Math.random() * emptyTables.length)];
    const alien = this.pickAlien();
    const dish = this.pickDishForAlien(alien);

    if (!dish) return null;

    table.customer = alien;
    table.order = dish;
    table.status = "waiting";
    table.patienceLeft = alien.patience;
    table.cookProgress = 0;
    table.cookTimeNeeded = 0;
    table.servedDish = null;

    return { table, alien, dish };
  }

  pickAlien() {
    // Más reputación = más chance de alienígenas exigentes
    const pool = [...GAME_DATA.aliens];
    if (this.state.reputation < 30) {
      // Principiantes ven más humanos, blip, gloppix, zorvax
      const common = pool.filter(a => 
        ["humano", "blip", "gloppix", "zorvax", "pufflin"].includes(a.id)
      );
      return common[Math.floor(Math.random() * common.length)];
    }
    return pool[Math.floor(Math.random() * pool.length)];
  }

  pickDishForAlien(alien) {
    const available = this.getAvailableDishes();
    if (available.length === 0) return null;

    // Preferir platos que coincidan con tags del alien
    const preferred = available.filter(d => 
      d.tags.some(t => alien.preferred.includes(t)) ||
      (d.preferredBy && d.preferredBy.includes(alien.id))
    );

    if (preferred.length > 0 && Math.random() > 0.3) {
      return preferred[Math.floor(Math.random() * preferred.length)];
    }
    return available[Math.floor(Math.random() * available.length)];
  }

  // ========== COCINA ==========
  canCook(dishId) {
    const dish = this.getDish(dishId);
    if (!dish) return false;
    return dish.ingredients.every(ing => (this.state.inventory[ing] || 0) > 0);
  }

  startCooking(tableId) {
    const table = this.tables.find(t => t.id === tableId);
    if (!table || table.status !== "waiting") return false;
    if (!this.canCook(table.order.id)) return false;

    // Consumir ingredientes
    table.order.ingredients.forEach(ing => {
      this.state.inventory[ing] = (this.state.inventory[ing] || 0) - 1;
    });

    // Calcular tiempo real
    let speedBonus = 0;
    if (this.state.purchasedUpgrades.includes("cocina_vel")) speedBonus += 0.15;
    if (this.state.purchasedUpgrades.includes("cocina_vel2")) speedBonus += 0.25;

    const furnitureSpeed = this.getFurnitureBonus("speed") / 100;
    speedBonus += furnitureSpeed;

    const baseTime = table.order.cookTime;
    table.cookTimeNeeded = Math.max(2, baseTime * (1 - speedBonus));
    table.cookProgress = 0;
    table.status = "cooking";
    this.save();
    return true;
  }

  // ========== SERVIR Y VALORAR ==========
  serveCustomer(tableId) {
    const table = this.tables.find(t => t.id === tableId);
    if (!table || table.status !== "ready") return null;

    const alien = table.customer;
    const dish = table.order;
    const rating = this.calculateRating(table);

    // Dinero
    let pay = dish.price;
    const tip = Math.round(pay * 0.15 * alien.tipMultiplier * (rating / 5));
    const total = pay + tip;
    this.earn(total);

    // Reputación
    const repGain = rating >= 4 ? 3 : rating >= 3 ? 1 : rating >= 2 ? 0 : -2;
    this.addReputation(repGain);

    // Estadísticas
    this.state.customersServed++;
    this.state.ratingSum += rating;
    this.state.ratingCount++;
    this.state.averageRating = this.state.ratingSum / this.state.ratingCount;

    // Limpiar mesa
    const result = {
      alien,
      dish,
      rating,
      money: total,
      tip,
      repGain
    };

    table.customer = null;
    table.order = null;
    table.status = "empty";
    table.patienceLeft = 0;
    table.cookProgress = 0;
    table.servedDish = null;

    this.save();
    return result;
  }

  calculateRating(table) {
    const alien = table.customer;
    const dish = table.order;
    let score = 3.0;

    // Preferencias
    const matchTags = dish.tags.filter(t => alien.preferred.includes(t)).length;
    const dislikeTags = dish.tags.filter(t => alien.disliked.includes(t)).length;
    score += matchTags * 0.6;
    score -= dislikeTags * 0.8;

    if (dish.preferredBy && dish.preferredBy.includes(alien.id)) {
      score += 1.2;
    }

    // Velocidad (paciencia restante)
    const patienceRatio = table.patienceLeft / alien.patience;
    if (patienceRatio > 0.7) score += 0.8;
    else if (patienceRatio > 0.4) score += 0.3;
    else if (patienceRatio < 0.2) score -= 1.0;

    // Bonos de local y muebles
    score += this.getLocation().baseSatisfaction / 10;
    score += this.getFurnitureBonus("satisfaction") / 10;
    score += (this.state.purchasedUpgrades.includes("calidad") ? 0.5 : 0);
    score += (this.state.purchasedUpgrades.includes("calidad2") ? 0.5 : 0);

    // Random pequeño
    score += (Math.random() - 0.5) * 0.4;

    return Math.max(1, Math.min(5, Math.round(score * 2) / 2)); // 0.5 steps
  }

  getFurnitureBonus(type) {
    let total = 0;
    this.state.ownedFurniture.forEach(fid => {
      const f = GAME_DATA.furniture.find(x => x.id === fid);
      if (f && f.bonus && f.bonus[type]) total += f.bonus[type];
    });
    return total;
  }

  // ========== COMPRAS ==========
  buyIngredient(id, amount = 5) {
    const ing = this.getIngredient(id);
    if (!ing) return false;
    const cost = ing.price * amount;
    if (!this.spend(cost)) return false;
    this.state.inventory[id] = (this.state.inventory[id] || 0) + amount;
    this.save();
    return true;
  }

  buyFurniture(id) {
    const f = GAME_DATA.furniture.find(x => x.id === id);
    if (!f || this.state.ownedFurniture.includes(id)) return false;
    if (!this.spend(f.price)) return false;
    this.state.ownedFurniture.push(id);
    this.save();
    return true;
  }

  buyUpgrade(id) {
    const u = GAME_DATA.upgrades.find(x => x.id === id);
    if (!u || this.state.purchasedUpgrades.includes(id)) return false;
    if (u.requires && !this.state.purchasedUpgrades.includes(u.requires)) return false;
    if (!this.spend(u.price)) return false;
    this.state.purchasedUpgrades.push(id);
    this.save();
    return true;
  }

  toggleMenuDish(dishId) {
    const dish = this.getDish(dishId);
    if (!dish || dish.unlock > this.state.locationId) return;
    const idx = this.state.menu.indexOf(dishId);
    if (idx >= 0) {
      if (this.state.menu.length <= 2) return; // mínimo 2 platos
      this.state.menu.splice(idx, 1);
    } else {
      this.state.menu.push(dishId);
    }
    this.save();
  }

  // ========== LOOP PRINCIPAL ==========
  start() {
    if (this.isRunning) return;
    this.isRunning = true;
    this.initTables();
    this.tickInterval = setInterval(() => this.tick(), 200);
  }

  stop() {
    this.isRunning = false;
    if (this.tickInterval) clearInterval(this.tickInterval);
  }

  tick() {
    if (!this.isRunning) return;

    // Spawn
    this.spawnTimer += 0.2;
    const spawnRate = Math.max(2.5, 6 - this.state.reputation / 80);
    if (this.spawnTimer >= spawnRate) {
      this.spawnTimer = 0;
      this.spawnCustomer();
    }

    // Actualizar mesas
    this.tables.forEach(table => {
      if (table.status === "waiting") {
        table.patienceLeft -= 0.2;
        if (table.patienceLeft <= 0) {
          // Cliente se va enfadado
          this.addReputation(-3);
          table.customer = null;
          table.order = null;
          table.status = "empty";
        }
      } else if (table.status === "cooking") {
        table.cookProgress += 0.2;
        if (table.cookProgress >= table.cookTimeNeeded) {
          table.status = "ready";
          table.cookProgress = table.cookTimeNeeded;
        }
      }
    });

    // Día (cada ~90 segundos de juego = 1 día)
    this.dayTimer += 0.2;
    if (this.dayTimer >= 90) {
      this.dayTimer = 0;
      this.state.day++;
      this.save();
    }
  }
}

// Instancia global
const game = new NebulaDiner();
