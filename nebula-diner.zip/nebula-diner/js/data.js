/**
 * NEBULA DINER - Datos del juego
 * Todos los alienígenas, platos, muebles y locales son originales.
 */

const GAME_DATA = {
  // ========== LOCALES / PROGRESIÓN ==========
  locations: [
    {
      id: 0,
      name: "Cafetería Básica",
      unlockMoney: 0,
      maxTables: 4,
      cookingSlots: 1,
      description: "Un pequeño puesto oxidado en el pasillo de la estación. ¡Pero tiene potencial!",
      baseSatisfaction: 0
    },
    {
      id: 1,
      name: "Restaurante Mediano",
      unlockMoney: 1000,
      maxTables: 8,
      cookingSlots: 2,
      description: "Más espacio, mejor iluminación y una cocina decente. Los clientes empiezan a hablar de ti.",
      baseSatisfaction: 5
    },
    {
      id: 2,
      name: "Bistró Espacial",
      unlockMoney: 10000,
      maxTables: 12,
      cookingSlots: 3,
      description: "Terraza con vistas a las estrellas y ambiente sofisticado. Ya eres alguien en la estación.",
      baseSatisfaction: 10
    },
    {
      id: 3,
      name: "Restaurante Premium",
      unlockMoney: 50000,
      maxTables: 18,
      cookingSlots: 4,
      description: "Zona VIP, neones alienígenas y cocina profesional. Los críticos empiezan a visitarte.",
      baseSatisfaction: 15
    },
    {
      id: 4,
      name: "Restaurante de Lujo Galáctico",
      unlockMoney: 150000,
      maxTables: 24,
      cookingSlots: 5,
      description: "Un local de prestigio interplanetario. Fuente de energía central y servicio impecable.",
      baseSatisfaction: 20
    },
    {
      id: 5,
      name: "Imperio Espacial",
      unlockMoney: 500000,
      maxTables: 32,
      cookingSlots: 6,
      description: "Tu imperio culinario. Múltiples salas, empleados y fama en toda la galaxia.",
      baseSatisfaction: 25
    }
  ],

  // ========== ALIENÍGENAS ORIGINALES ==========
  aliens: [
    {
      id: "gloppix",
      name: "Gloppix",
      emoji: "🫧",
      color: "#a78bfa",
      personality: "Gelatinoso y emotivo",
      preferred: ["batido", "liquido", "suave"],
      disliked: ["crujiente", "picante"],
      patience: 45,
      tipMultiplier: 1.1,
      description: "Blob translúcido de colores cambiantes. Se derrite de placer con batidos."
    },
    {
      id: "zorvax",
      name: "Zorvax",
      emoji: "🪲",
      color: "#34d399",
      personality: "Rápido y exigente",
      preferred: ["rapido", "crujiente", "hamburguesa"],
      disliked: ["gourmet", "lento"],
      patience: 30,
      tipMultiplier: 1.0,
      description: "Insectoide de 4 brazos. Ama la comida rápida y crujiente."
    },
    {
      id: "lumaari",
      name: "Lumaari",
      emoji: "✨",
      color: "#f0abfc",
      personality: "Elegante y sensible",
      preferred: ["gourmet", "bonito", "delicado"],
      disliked: ["rapido", "graso"],
      patience: 50,
      tipMultiplier: 1.4,
      description: "Criatura etérea de luz pastel. Solo aprecia platos visualmente hermosos."
    },
    {
      id: "kroktar",
      name: "Krok'thar",
      emoji: "🦎",
      color: "#fb923c",
      personality: "Voraz y ruidoso",
      preferred: ["grande", "picante", "carne"],
      disliked: ["ligero", "dulce"],
      patience: 40,
      tipMultiplier: 1.2,
      description: "Reptiliano robusto. Quiere raciones enormes y picantes."
    },
    {
      id: "pufflin",
      name: "Pufflin",
      emoji: "🐥",
      color: "#fde68a",
      personality: "Dulce y esponjoso",
      preferred: ["dulce", "postre", "suave"],
      disliked: ["picante", "amargo"],
      patience: 55,
      tipMultiplier: 1.15,
      description: "Pequeño y redondo con plumas pastel. Se infla cuando está feliz."
    },
    {
      id: "vexil",
      name: "Vexil",
      emoji: "🤖",
      color: "#67e8f9",
      personality: "Eficiente y lógico",
      preferred: ["nutritivo", "equilibrado", "rapido"],
      disliked: ["excesivo", "basura"],
      patience: 35,
      tipMultiplier: 1.05,
      description: "Híbrido robótico-orgánico. Valora la eficiencia y la nutrición."
    },
    {
      id: "snorflax",
      name: "Snorflax",
      emoji: "🐻",
      color: "#a8a29e",
      personality: "Lento y generoso",
      preferred: ["grande", "todo", "abundante"],
      disliked: ["pequeño"],
      patience: 70,
      tipMultiplier: 1.3,
      description: "Gran masa peluda con varias bocas. Come de todo y deja buenas propinas."
    },
    {
      id: "aetheri",
      name: "Aetheri",
      emoji: "💎",
      color: "#c4b5fd",
      personality: "Exigente y refinado",
      preferred: ["gourmet", "raro", "cristal"],
      disliked: ["basico", "rapido"],
      patience: 40,
      tipMultiplier: 1.6,
      description: "Piel de cristal y aletas flotantes. Solo come lo más exclusivo."
    },
    {
      id: "blip",
      name: "Blip",
      emoji: "⭐",
      color: "#fbbf24",
      personality: "Hiperactivo",
      preferred: ["rapido", "energetico", "snack"],
      disliked: ["lento", "pesado"],
      patience: 25,
      tipMultiplier: 0.9,
      description: "Minúsculo ser de energía pura. Corre por el local y pide snacks veloces."
    },
    {
      id: "humano",
      name: "Humano",
      emoji: "🧑‍🚀",
      color: "#94a3b8",
      personality: "Familiar y estable",
      preferred: ["clasico", "hamburguesa", "cafe"],
      disliked: ["raro"],
      patience: 50,
      tipMultiplier: 1.0,
      description: "Trabajador o turista de la estación. Prefiere lo conocido y reconfortante."
    }
  ],

  // ========== PLATOS ==========
  dishes: [
    // Básicos
    {
      id: "cafe",
      name: "Café Espacial Negro",
      emoji: "☕",
      category: "basico",
      price: 8,
      cookTime: 4,
      ingredients: ["cafe"],
      tags: ["cafe", "rapido", "energetico", "clasico"],
      unlock: 0
    },
    {
      id: "batido",
      name: "Batido de Nebulosa",
      emoji: "🥤",
      category: "basico",
      price: 12,
      cookTime: 5,
      ingredients: ["fruta", "leche"],
      tags: ["batido", "liquido", "suave", "dulce"],
      unlock: 0
    },
    {
      id: "hamburguesa",
      name: "Hamburguesa de Estación",
      emoji: "🍔",
      category: "basico",
      price: 18,
      cookTime: 8,
      ingredients: ["carne", "pan", "verdura"],
      tags: ["hamburguesa", "rapido", "crujiente", "clasico", "carne"],
      unlock: 0
    },
    {
      id: "tostada",
      name: "Tostada de Plasma",
      emoji: "🍞",
      category: "basico",
      price: 10,
      cookTime: 5,
      ingredients: ["pan", "energia"],
      tags: ["rapido", "crujiente", "energetico"],
      unlock: 0
    },
    {
      id: "sopa",
      name: "Sopa de Meteorito",
      emoji: "🍲",
      category: "basico",
      price: 14,
      cookTime: 7,
      ingredients: ["verdura", "caldo"],
      tags: ["liquido", "suave", "nutritivo"],
      unlock: 0
    },
    {
      id: "galletas",
      name: "Galletas de Asteroides",
      emoji: "🍪",
      category: "basico",
      price: 9,
      cookTime: 6,
      ingredients: ["harina", "azucar"],
      tags: ["dulce", "snack", "rapido"],
      unlock: 0
    },

    // Intermedios
    {
      id: "wrap",
      name: "Wrap de Tentáculo Crujiente",
      emoji: "🌯",
      category: "intermedio",
      price: 22,
      cookTime: 9,
      ingredients: ["carne", "verdura", "pan"],
      tags: ["crujiente", "rapido", "carne"],
      unlock: 1
    },
    {
      id: "pizza",
      name: "Pizza de Queso de Luna",
      emoji: "🍕",
      category: "intermedio",
      price: 28,
      cookTime: 12,
      ingredients: ["harina", "queso", "verdura"],
      tags: ["grande", "clasico", "abundante"],
      unlock: 1
    },
    {
      id: "ensalada",
      name: "Ensalada de Algas Galácticas",
      emoji: "🥗",
      category: "intermedio",
      price: 20,
      cookTime: 7,
      ingredients: ["verdura", "algas"],
      tags: ["ligero", "nutritivo", "bonito", "equilibrado"],
      unlock: 1
    },
    {
      id: "protein",
      name: "Protein-Blocks",
      emoji: "🧱",
      category: "intermedio",
      price: 16,
      cookTime: 6,
      ingredients: ["proteina"],
      tags: ["nutritivo", "equilibrado", "rapido"],
      unlock: 1
    },
    {
      id: "cafe_crema",
      name: "Café con Crema de Cometa",
      emoji: "🍵",
      category: "intermedio",
      price: 15,
      cookTime: 5,
      ingredients: ["cafe", "leche"],
      tags: ["cafe", "suave", "dulce", "energetico"],
      unlock: 1
    },
    {
      id: "bowl",
      name: "Bowl de Granos Estelares",
      emoji: "🥣",
      category: "intermedio",
      price: 24,
      cookTime: 10,
      ingredients: ["grano", "verdura", "proteina"],
      tags: ["nutritivo", "equilibrado", "abundante"],
      unlock: 2
    },

    // Gourmet / Alienígenas
    {
      id: "sopa_gloppix",
      name: "Sopa de Lágrimas de Gloppix",
      emoji: "💧",
      category: "gourmet",
      price: 35,
      cookTime: 11,
      ingredients: ["caldo", "esencia", "fruta"],
      tags: ["liquido", "suave", "gourmet", "raro"],
      unlock: 2,
      preferredBy: ["gloppix"]
    },
    {
      id: "filete_krok",
      name: "Filete de Krok'thar Picante",
      emoji: "🥩",
      category: "gourmet",
      price: 42,
      cookTime: 14,
      ingredients: ["carne", "especias"],
      tags: ["grande", "picante", "carne", "gourmet"],
      unlock: 2,
      preferredBy: ["kroktar"]
    },
    {
      id: "postre_pufflin",
      name: "Postre de Nube de Pufflin",
      emoji: "☁️",
      category: "gourmet",
      price: 30,
      cookTime: 9,
      ingredients: ["azucar", "crema", "fruta"],
      tags: ["dulce", "postre", "suave", "bonito"],
      unlock: 2,
      preferredBy: ["pufflin"]
    },
    {
      id: "sushi_aetheri",
      name: "Sushi de Cristal Aetheri",
      emoji: "🍣",
      category: "gourmet",
      price: 55,
      cookTime: 15,
      ingredients: ["pescado", "cristal", "algas"],
      tags: ["gourmet", "raro", "cristal", "bonito", "delicado"],
      unlock: 3,
      preferredBy: ["aetheri"]
    },
    {
      id: "coctel_vexil",
      name: "Cóctel de Energía Vexil",
      emoji: "⚡",
      category: "gourmet",
      price: 28,
      cookTime: 6,
      ingredients: ["energia", "proteina"],
      tags: ["energetico", "nutritivo", "rapido", "equilibrado"],
      unlock: 2,
      preferredBy: ["vexil", "blip"]
    },
    {
      id: "banquete_snorf",
      name: "Banquete Multi-Boca Snorflax",
      emoji: "🍽️",
      category: "gourmet",
      price: 65,
      cookTime: 18,
      ingredients: ["carne", "verdura", "grano", "queso"],
      tags: ["grande", "abundante", "todo", "gourmet"],
      unlock: 3,
      preferredBy: ["snorflax"]
    },
    {
      id: "pastel_lumaari",
      name: "Pastel de Luz Lumaari",
      emoji: "🎂",
      category: "gourmet",
      price: 48,
      cookTime: 13,
      ingredients: ["harina", "luz", "fruta"],
      tags: ["dulce", "bonito", "gourmet", "delicado"],
      unlock: 3,
      preferredBy: ["lumaari"]
    },
    {
      id: "snack_blip",
      name: "Snack de Velocidad Blip",
      emoji: "🚀",
      category: "gourmet",
      price: 14,
      cookTime: 3,
      ingredients: ["energia", "azucar"],
      tags: ["rapido", "energetico", "snack"],
      unlock: 1,
      preferredBy: ["blip"]
    }
  ],

  // ========== INGREDIENTES ==========
  ingredients: [
    { id: "cafe", name: "Café", emoji: "☕", price: 2 },
    { id: "fruta", name: "Fruta Espacial", emoji: "🍎", price: 3 },
    { id: "leche", name: "Leche de Nebulosa", emoji: "🥛", price: 2 },
    { id: "carne", name: "Carne de Asteroide", emoji: "🥩", price: 5 },
    { id: "pan", name: "Pan Estelar", emoji: "🍞", price: 2 },
    { id: "verdura", name: "Verduras Galácticas", emoji: "🥬", price: 3 },
    { id: "energia", name: "Célula de Energía", emoji: "⚡", price: 4 },
    { id: "caldo", name: "Caldo de Meteorito", emoji: "🥣", price: 3 },
    { id: "harina", name: "Harina Cósmica", emoji: "🌾", price: 2 },
    { id: "azucar", name: "Azúcar de Cometa", emoji: "🍬", price: 2 },
    { id: "queso", name: "Queso de Luna", emoji: "🧀", price: 4 },
    { id: "algas", name: "Algas Galácticas", emoji: "🌿", price: 3 },
    { id: "proteina", name: "Bloques de Proteína", emoji: "🧬", price: 4 },
    { id: "grano", name: "Granos Estelares", emoji: "🌾", price: 3 },
    { id: "especias", name: "Especias Picantes", emoji: "🌶️", price: 3 },
    { id: "esencia", name: "Esencia de Gloppix", emoji: "💧", price: 6 },
    { id: "crema", name: "Crema de Nube", emoji: "☁️", price: 4 },
    { id: "pescado", name: "Pescado de Cristal", emoji: "🐟", price: 7 },
    { id: "cristal", name: "Cristal Comestible", emoji: "💎", price: 8 },
    { id: "luz", name: "Partículas de Luz", emoji: "✨", price: 6 }
  ],

  // ========== MUEBLES ==========
  furniture: [
    // Mesas
    { id: "mesa_basica", name: "Mesa Básica", emoji: "🪑", category: "mesa", price: 50, bonus: { capacity: 0 }, desc: "Mesa simple de metal." },
    { id: "mesa_redonda", name: "Mesa Redonda Holo", emoji: "⭕", category: "mesa", price: 180, bonus: { satisfaction: 3 }, desc: "Superficie holográfica suave." },
    { id: "mesa_vip", name: "Mesa VIP Cristal", emoji: "💎", category: "mesa", price: 450, bonus: { satisfaction: 8 }, desc: "Para clientes exigentes." },
    { id: "mesa_flotante", name: "Mesa Flotante", emoji: "🛸", category: "mesa", price: 800, bonus: { satisfaction: 12 }, desc: "Anti-gravedad integrada." },

    // Sillas
    { id: "silla_simple", name: "Taburete Simple", emoji: "💺", category: "silla", price: 30, bonus: {}, desc: "Funcional y barato." },
    { id: "silla_acolchada", name: "Silla Acolchada", emoji: "🛋️", category: "silla", price: 120, bonus: { satisfaction: 4 }, desc: "Más cómoda = más propina." },
    { id: "asiento_tentaculo", name: "Asiento Tentáculo", emoji: "🐙", category: "silla", price: 280, bonus: { satisfaction: 7 }, desc: "Se adapta a cualquier forma." },
    { id: "trono", name: "Trono Alienígena", emoji: "👑", category: "silla", price: 600, bonus: { satisfaction: 12 }, desc: "Impresiona a todos." },

    // Iluminación
    { id: "lampara_simple", name: "Lámpara de Techo", emoji: "💡", category: "luz", price: 40, bonus: {}, desc: "Iluminación básica." },
    { id: "neon", name: "Neón Flotante", emoji: "🌈", category: "luz", price: 200, bonus: { satisfaction: 5 }, desc: "Ambiente moderno." },
    { id: "plasma", name: "Lámpara de Plasma", emoji: "🔮", category: "luz", price: 350, bonus: { satisfaction: 8 }, desc: "Luz viva y cambiante." },

    // Plantas
    { id: "cactus", name: "Cactus Espacial", emoji: "🌵", category: "planta", price: 60, bonus: { satisfaction: 2 }, desc: "No necesita agua." },
    { id: "hongo", name: "Hongo Luminoso", emoji: "🍄", category: "planta", price: 150, bonus: { satisfaction: 5 }, desc: "Brilla suavemente." },
    { id: "arbol_cristal", name: "Árbol de Cristal", emoji: "🌳", category: "planta", price: 400, bonus: { satisfaction: 10 }, desc: "Belleza pura." },

    // Decoración
    { id: "cartel", name: "Cartel de Comida", emoji: "🪧", category: "deco", price: 80, bonus: { attraction: 5 }, desc: "Atrae más clientes." },
    { id: "fuente", name: "Fuente de Bebida", emoji: "⛲", category: "deco", price: 300, bonus: { satisfaction: 6 }, desc: "Ambiente relajante." },
    { id: "jukebox", name: "Jukebox Espacial", emoji: "🎵", category: "deco", price: 500, bonus: { satisfaction: 9 }, desc: "Música que gusta a todos." },

    // Utilidad
    { id: "estanteria", name: "Estantería de Ingredientes", emoji: "📦", category: "utilidad", price: 250, bonus: { inventory: 10 }, desc: "+10 capacidad de inventario." },
    { id: "estacion_rapida", name: "Estación de Servicio Rápida", emoji: "⚡", category: "utilidad", price: 700, bonus: { speed: 15 }, desc: "+15% velocidad de servicio." },
    { id: "robot", name: "Robot Camarero Básico", emoji: "🤖", category: "utilidad", price: 1200, bonus: { speed: 25, capacity: 1 }, desc: "Ayuda a servir más rápido." }
  ],

  // ========== MEJORAS PERMANENTES ==========
  upgrades: [
    { id: "cocina_vel", name: "Cocina Rápida Nv.1", emoji: "🔥", price: 400, effect: { cookSpeed: 0.15 }, desc: "Cocinas un 15% más rápido." },
    { id: "cocina_vel2", name: "Cocina Rápida Nv.2", emoji: "🔥", price: 1500, effect: { cookSpeed: 0.25 }, desc: "Cocinas un 25% más rápido.", requires: "cocina_vel" },
    { id: "calidad", name: "Ingredientes Premium", emoji: "⭐", price: 800, effect: { quality: 10 }, desc: "+10 satisfacción base por calidad." },
    { id: "calidad2", name: "Ingredientes Exóticos", emoji: "🌟", price: 3000, effect: { quality: 20 }, desc: "+20 satisfacción base.", requires: "calidad" },
    { id: "reputacion", name: "Marketing Espacial", emoji: "📢", price: 600, effect: { repGain: 0.2 }, desc: "+20% ganancia de reputación." },
    { id: "capacidad", name: "Ampliación de Cola", emoji: "🚪", price: 1000, effect: { maxWaiting: 2 }, desc: "Más clientes pueden esperar." }
  ]
};
