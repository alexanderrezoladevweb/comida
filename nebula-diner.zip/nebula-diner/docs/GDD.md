# Game Design Document — Nebula Diner

**Versión:** 1.0  
**Tipo:** Simulador de gestión de restaurante espacial (mobile-first)  
**Estilo visual:** Indie Cartoon Moderno, colorido, simpático, no realista  
**Plataforma objetivo:** Móvil (Android/iOS) + Web (prototipo actual)

---

## 1. Concepto principal

El jugador gestiona un pequeño local de comida en una estación espacial. Empieza con una cafetería básica y, a medida que gana dinero y reputación, desbloquea locales cada vez más grandes y premium. Los clientes son principalmente alienígenas originales con personalidades, preferencias y reacciones únicas.

**Fantasía del jugador:** “Quiero convertir este agujero oxidado en el mejor restaurante de la galaxia.”

**Sensación clave:** Progresión constante, feedback inmediato, personalidad a través de los alienígenas.

---

## 2. Pilares de diseño

1. **Progresión visible y adictiva** — cada cliente, cada mueble y cada local se siente como un paso adelante.
2. **Personalidad alienígena** — los clientes no son genéricos; cada uno tiene gustos y reacciones memorables.
3. **Gestión ligera pero profunda** — fácil de entender en 30 segundos, con capas de optimización.
4. **Estética cartoon cálida** — colores vibrantes, formas redondeadas, animaciones jugosas.
5. **Sin frustración punitiva** — los fallos cuestan reputación, no destruyen la partida.

---

## 3. Loop de juego principal

1. Clientes llegan automáticamente según reputación.
2. El jugador ve el pedido y decide cocinarlo (consume ingredientes).
3. Mientras cocina, gestiona otras mesas, compra ingredientes o decora.
4. Sirve el plato → el cliente valora (1-5 estrellas) → dinero + reputación.
5. Con dinero se compran muebles, mejoras y se desbloquean locales.
6. Se repite con más mesas, más platos y clientes más exigentes.

**Duración de una sesión ideal:** 5-15 minutos.

---

## 4. Sistema de progresión de locales

| Nivel | Nombre                        | Dinero total ganado | Mesas | Slots cocina | Satisfacción base |
|-------|-------------------------------|---------------------|-------|--------------|-------------------|
| 0     | Cafetería Básica              | 0                   | 4     | 1            | 0                 |
| 1     | Restaurante Mediano           | 1.000 $             | 8     | 2            | +5                |
| 2     | Bistró Espacial               | 10.000 $            | 12    | 3            | +10               |
| 3     | Restaurante Premium           | 50.000 $            | 18    | 4            | +15               |
| 4     | Restaurante de Lujo Galáctico | 150.000 $           | 24    | 5            | +20               |
| 5     | Imperio Espacial              | 500.000 $           | 32    | 6            | +25               |

Al desbloquear un local, el jugador mantiene sus muebles y menú; solo gana espacio y estética base mejorada.

---

## 5. Alienígenas (10 tipos originales)

Cada alienígena tiene:
- Nombre y diseño visual único (emoji + color en prototipo)
- Tags de preferencia y rechazo
- Paciencia base (segundos)
- Multiplicador de propina
- Descripción de personalidad

Los alienígenas más exigentes (Aetheri, Lumaari) aparecen con más frecuencia a medida que sube la reputación.

---

## 6. Sistema de comida

### Categorías
- **Básicos** (inicio): café, batido, hamburguesa, tostada, sopa, galletas
- **Intermedios**: wrap, pizza, ensalada, protein-blocks, café con crema, bowl
- **Gourmet / Alienígenas**: platos especiales ligados a cada especie + platos premium

Cada plato tiene:
- Precio de venta
- Tiempo de cocción base
- Lista de ingredientes
- Tags (para matching con preferencias)
- Nivel de local mínimo para desbloquear

El jugador elige qué platos ofrece en el menú (mínimo 2). Más variedad = más tipos de clientes contentos.

---

## 7. Muebles y decoración

Categorías:
- Mesas
- Sillas / Asientos
- Iluminación
- Plantas alienígenas
- Decoración temática
- Utilidad (estanterías, robots, estaciones rápidas)

Muchos muebles dan bonos pasivos:
- +Satisfacción
- +Velocidad de servicio
- +Capacidad de inventario
- +Atracción de clientes

En el prototipo actual la compra es inmediata y el bono se aplica globalmente. En la versión completa se implementará colocación libre o por slots visuales.

---

## 8. Economía y reputación

- **Dinero**: se gana sirviendo (precio del plato + propina según valoración y tipo de alienígena).
- **Reputación**: sube con buenas valoraciones, baja con clientes que se van o valoraciones bajas.
- La reputación influye en la frecuencia de llegada de clientes y en la aparición de alienígenas más raros/exigentes.

---

## 9. Mejoras permanentes

- Velocidad de cocina (varios niveles)
- Calidad de ingredientes (+satisfacción base)
- Marketing (más reputación por cliente)
- Ampliación de cola de espera

---

## 10. Interfaz (prototipo actual)

- **Top bar**: dinero, reputación, día, nombre del local
- **Vista central**: mesas con clientes + zona de cocina
- **Bottom nav**: 6 paneles (Clientes, Menú, Cocina, Muebles, Mercado, Mejoras)
- **Modales**: valoración del cliente y desbloqueo de local
- **Notificaciones flotantes**

Diseño mobile-first, dark theme espacial, tipografía Nunito + Orbitron.

---

## 11. Guardado

localStorage automático después de cada acción económica importante.

---

## 12. Monetización sugerida (versión comercial)

- Versión premium (pago único) o freemium suave
- Packs cosméticos de muebles y temas
- Pases de temporada con alienígenas y platos limitados
- Anuncios opcionales para dinero extra o skips (nunca pay-to-win agresivo)

---

## 13. Métricas de éxito deseadas

- Sesión media > 8 minutos
- Retención D1 > 40%
- El jugador siente “solo una mejora más” de forma natural
- Los alienígenas se vuelven memorables (el jugador los nombra)

---

## 14. Próximos pasos técnicos recomendados

1. Sustituir emojis por sprites cartoon originales
2. Añadir animaciones de entrada/salida de clientes y reacciones
3. Mini-juegos de cocina (timing, orden de ingredientes, etc.)
4. Sistema de colocación visual de muebles
5. Audio (música chiptune espacial + SFX jugosos)
6. Port a motor nativo o híbrido (Godot 4 / Unity / Flutter + Flame)

---

**Documento vivo.** Este GDD refleja el estado del prototipo jugable v1.0 y la visión completa del juego.
