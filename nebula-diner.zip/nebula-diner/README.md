# 🌌 Nebula Diner

**Simulador de Bar-Restaurante Espacial**  
Prototipo web completo · Estilo Indie Cartoon Moderno

![Version](https://img.shields.io/badge/version-1.0.0-purple)
![Status](https://img.shields.io/badge/status-playable%20prototype-green)
![License](https://img.shields.io/badge/license-MIT-blue)

---

## 🎮 Descripción

**Nebula Diner** es un simulador de gestión de restaurante ambientado en el espacio. Empiezas con una pequeña cafetería oxidada en una estación espacial y, a base de cocinar para alienígenas originales, decorar, mejorar y gestionar el menú, puedes convertirlo en un imperio culinario galáctico.

El juego está diseñado con un estilo **indie cartoon moderno**: colorido, expresivo, simpático y adictivo.

### Características principales

- ✅ **10 tipos de alienígenas originales** con personalidades, preferencias y reacciones únicas
- ✅ **Sistema de cocina** con ingredientes, tiempos y valoraciones
- ✅ **Menú editable** (básicos → intermedios → gourmet alienígenas)
- ✅ **Progresión de 6 locales** (1.000 $ → 10.000 $ → 50.000 $ → 150.000 $ → 500.000 $)
- ✅ **Catálogo de muebles** con bonos de satisfacción, velocidad y capacidad
- ✅ **Mercado de ingredientes** + inventario
- ✅ **Mejoras permanentes** (velocidad de cocina, calidad, reputación...)
- ✅ **Sistema de reputación y dinero** claro
- ✅ **Guardado automático** en localStorage
- ✅ **Interfaz responsive** lista para móvil y escritorio

---

## 🚀 Cómo jugar (en el navegador)

1. Abre `index.html` en cualquier navegador moderno (Chrome, Firefox, Edge, Safari).
2. Pulsa **Nueva Partida**.
3. Los clientes llegan solos. Toca **Cocinar** → espera → **Servir**.
4. Usa la barra inferior para:
   - Ver estadísticas
   - Editar el menú
   - Comprar ingredientes
   - Comprar muebles
   - Mejorar el local y la cocina

### Controles
- Todo se controla con clics/toques.
- No hay teclado obligatorio.

---

## 📁 Estructura del proyecto

```
nebula-diner/
├── index.html              # Entrada principal
├── css/
│   └── styles.css          # Estilos completos (cartoon espacial)
├── js/
│   ├── data.js             # Todos los datos del juego (aliens, platos, muebles...)
│   ├── game.js             # Lógica de negocio (economía, clientes, cocina, progresión)
│   ├── ui.js               # Interfaz, paneles, notificaciones, render
│   └── main.js             # Arranque y pantalla de título
├── assets/
│   ├── images/             # (placeholder para futuros sprites)
│   └── sounds/             # (placeholder para audio)
├── docs/
│   └── GDD.md              # Game Design Document completo
└── README.md
```

---

## 🛠️ Tecnologías

- HTML5 + CSS3 + JavaScript vanilla (ES6+)
- Sin frameworks (fácil de portar a Unity, Godot, Flutter o React Native)
- localStorage para guardado
- Diseño mobile-first

---

## 📈 Roadmap hacia versión completa

| Fase | Contenido | Estado |
|------|-----------|--------|
| 1 | Prototipo web jugable (este repo) | ✅ Completo |
| 2 | Sprites cartoon + animaciones de alienígenas | Pendiente |
| 3 | Mini-juegos de cocina más elaborados | Pendiente |
| 4 | Colocación libre de muebles (drag & drop) | Pendiente |
| 5 | Audio, partículas y efectos | Pendiente |
| 6 | Port a móvil (Capacitor / Unity / Godot) | Pendiente |
| 7 | Eventos diarios, empleados, modo foto | Pendiente |

---

## 👽 Alienígenas incluidos

| Nombre | Emoji | Preferencia principal |
|--------|-------|-----------------------|
| Gloppix | 🫧 | Batidos y comida líquida |
| Zorvax | 🪲 | Comida rápida y crujiente |
| Lumaari | ✨ | Gourmet visualmente bonito |
| Krok'thar | 🦎 | Raciones grandes y picantes |
| Pufflin | 🐥 | Dulces y postres |
| Vexil | 🤖 | Nutritivo y eficiente |
| Snorflax | 🐻 | Cantidades enormes |
| Aetheri | 💎 | Exclusivo y raro |
| Blip | ⭐ | Snacks ultrarrápidos |
| Humano | 🧑‍🚀 | Clásicos reconfortantes |

---

## 📦 Cómo subir a GitHub

```bash
cd nebula-diner
git init
git add .
git commit -m "Initial commit: Nebula Diner playable prototype v1.0"
git branch -M main
git remote add origin https://github.com/TU_USUARIO/nebula-diner.git
git push -u origin main
```

Luego activa **GitHub Pages** en Settings → Pages → Source: main branch para jugar online.

---

## 📄 Licencia

MIT License. Puedes usarlo, modificarlo y basarte en él libremente.

---

**Hecho con 💜 para soñadores de restaurantes espaciales.**  
Diseño y prototipo listos para que un equipo o un desarrollador solitario lo convierta en un juego móvil completo.
